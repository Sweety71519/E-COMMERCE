import React from 'react'

export default function Confirmation() {
  return (
  <div className="containar-fluid my-5 text-center">
    <h3 className='text-success'> Thank You !!!!</h3>
    <h4>Your Order Has Been Placed</h4>
    <h4>Now You Can Track Your Order in Profile Section  </h4>
  </div>
  )
}
